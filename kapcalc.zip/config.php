<?php

$db = new mysqli('localhost', 'root', '', 'kapcalc');
global $db;
?>